﻿using UnityEngine;
using System.Collections.Generic;

public class CellController : MonoBehaviour {

    public List<AuxinController> myAuxins;

    //cell name
    public string cellName
    {
        set
        {
            name = value;
            cellCache[name] = gameObject;
        }
    }
    //static structure to easier find cells by name
    private static Dictionary<string, GameObject> cellCache = new Dictionary<string, GameObject>();

    public static GameObject GetCellByName(string idName)
    {
        if (cellCache.ContainsKey(idName)) {
            return cellCache[idName];
        }
        else
        {
            Debug.LogWarning(idName + ": Cell not found!!!");
            return null;
        }
    }

    //thermical confort variables
    //air temperature (ta)
    public float airTemperature;
    //room it belongs
    public GameObject room;
    //agents who are inside it
    public List<GameObject> agents;
    //any source of heat
    public GameObject heatSource;
    //if cell is part of wall
    public bool isWall;
    //wall value (0 = wall, c = normal)
    public float wallFilter;
    //if cell is a door
    public bool isDoor;

    private void Awake()
    {
        //default: false
        //isWall = false;
        //isDoor = false;
        GetComponent<Renderer>().sharedMaterial = Resources.Load("Materials/Wall") as Material;
        agents = new List<GameObject>();
        // heat diffusivity(air diffusivity = 1.9 × 10 - 5)
        if (!isWall)
        {
            wallFilter = 0.019f;
        }
    }

    // Update is called once per frame
    private void Update()
    {
        //if it is not wall
        if (!isWall)
        {
            //ResetCell();

            //update its material according its temperature
            if (airTemperature < 10)
            {
                GetComponent<Renderer>().sharedMaterial = Resources.Load("Materials/Freezing") as Material;
            }
            else if (airTemperature >= 10 && airTemperature < 18)
            {
                GetComponent<Renderer>().sharedMaterial = Resources.Load("Materials/Cold") as Material;
            }
            else if (airTemperature >= 18 && airTemperature < 25)
            {
                GetComponent<Renderer>().sharedMaterial = Resources.Load("Materials/Normal") as Material;
            }
            else if (airTemperature >= 25 && airTemperature < 29)
            {
                GetComponent<Renderer>().sharedMaterial = Resources.Load("Materials/Hot") as Material;
            }
            else if (airTemperature >= 29)
            {
                GetComponent<Renderer>().sharedMaterial = Resources.Load("Materials/Hell") as Material;
            }
        }

        /*if (agents.Count > 0)
        {
            Debug.Log(name + " - " + agents[0].name);
        }*/
    }

    public void StartList()
    {
        myAuxins = new List<AuxinController>();
        agents = new List<GameObject>();
    }

    public void StartAgentList()
    {
        agents = new List<GameObject>();
    }

    //add a new auxin on myAuxins
    public void AddAuxin(AuxinController auxin)
    {
        myAuxins.Add(auxin);
    }

    //return all auxins in this cell
    public List<AuxinController> GetAuxins() {
        return myAuxins;     
    }
}
