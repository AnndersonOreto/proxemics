﻿public class DurupinarClass {
    //constructors
    public DurupinarClass()
    {
	    leadership = panic = impatience = rightPreference = personalSpace = waitingRadius = walkingSpeed = gesturing = waitingTimer = 0;
        trained = communication = pushing = false;
    }

    //Durupinar values
    private float leadership, panic, impatience, rightPreference, personalSpace, waitingRadius, walkingSpeed, gesturing;
    private int waitingTimer;
    private bool trained, communication, pushing;

    //calculate the durupinar values according OCEAN informed
    public void CalculateDurupinar(float O, float C, float E, float A, float N)
    {
        //leadership
        leadership = E + (1 - N);
        if (leadership > 1) leadership = 1;

        //trained
        if (O >= 0.5f)
        {
            trained = true;
        }
        else trained = false;

        //communication
        if (E >= 0.5f)
        {
            communication = true;
        }
        else communication = false;

        //panic
        float cFuntion = 0;
        if(C >= 0)
        {
            cFuntion = (-2 * C) + 2;
        }
        panic = N + cFuntion;
        if (panic > 1) panic = 1;

        //impatience
        float eFunction = 0;
        if (E >= 0)
        {
            eFunction = (2 * E) - 1;
        }
        impatience = eFunction + (1 - A) + (1 - C);
        if (impatience > 1) impatience = 1;

        //pushing
        if (E + (1 - A) > 0.5f)
        {
            pushing = true;
        }
        else pushing = false;

        //right preference
        rightPreference = 0;
        float rFunction = A + C;
        if(A < 0 || C < 0)
        {
            rFunction = 0.5f;
        }
        if (rFunction >= 0.5f)
        {
            rightPreference = 1;
        }
        if (rightPreference > 1) rightPreference = 1;

        //personal space
        //already using the hall personal space. Plus, the Durupinar personal space is not fixed, since it depends if agent is behind or in front of another agent.

        //waiting radius
        waitingRadius = 0.25f;
        if(A >= 1/3 && A <= 2 / 3)
        {
            waitingRadius = 0.45f;
        }else if (A > 2 / 3 && A <= 1)
        {
            waitingRadius = 0.65f;
        }

        //waiting timer
        waitingTimer = 1;
        if (A >= 1 / 3 && A <= 2 / 3)
        {
            waitingTimer = 5;
        }
        else if (A > 2 / 3 && A <= 1)
        {
            waitingTimer = 50;
        }

        //exploring the environment
        //we already have this with the looking for state. Plus, it just defines the number of places an agent will visit before leave.

        //walking speed
        walkingSpeed = 1 + E;

        //gesturing
        gesturing = E * 10;
    }

    //Getters and Setters
    public float GetLeadership()
    {
        return leadership;
    }
    public void SetLeadership(float value)
    {
        leadership = value;
    }
    public bool GetTrained()
    {
        return trained;
    }
    public void SetTrained(bool value)
    {
        trained = value;
    }
    public bool GetCommunication()
    {
        return communication;
    }
    public void SetCommunication(bool value)
    {
        communication = value;
    }
    public float GetPanic()
    {
        return panic;
    }
    public void SetPanic(float value)
    {
        panic = value;
    }
    public float GetImpatience()
    {
        return impatience;
    }
    public void SetImpatience(float value)
    {
        impatience = value;
    }
    public bool GetPushing()
    {
        return pushing;
    }
    public void SetPushing(bool value)
    {
        pushing = value;
    }
    public float GetRightPreference()
    {
        return rightPreference;
    }
    public void SetRightPreference(float value)
    {
        rightPreference = value;
    }
    public float GetWaitingRadius()
    {
        return waitingRadius;
    }
    public void SetWaitingRadius(float value)
    {
        waitingRadius = value;
    }
    public int GetWaitingTimer()
    {
        return waitingTimer;
    }
    public void SetWaitingTimer(int value)
    {
        waitingTimer = value;
    }
    public float GetWalkingSpeed()
    {
        return walkingSpeed;
    }
    public void SetWalkingSpeed(float value)
    {
        walkingSpeed = value;
    }
    public float GetGesturing()
    {
        return gesturing;
    }
    public void SetGesturing(float value)
    {
        gesturing = value;
    }
}
