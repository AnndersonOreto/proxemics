﻿using System.Collections.Generic;
using UnityEngine;

public class AgentGroupController : MonoBehaviour {

    //agents of this groups
    public List<GameObject> agents;
    //cell
    public GameObject cell;

    //goals schedule
    public List<GameObject> go;
    //goals intentions
    public List<float> intentions;
    //goals desire
    public List<float> desire;
    //group cohesion
    public float cohesion;
    //group mean speed
    public float meanSpeed;
    //group mean speed deviation
    public float meanSpeedDeviation;
    //group leader
    public GameObject leader;
    //group objective (restaurant, theater, ...)
    public GameController.roomTypes objective;

    //terrain limits
    private Vector3 terrainLimits;

    //cultural stuff
    //Hofstede class
    public HofstedeClass hofstede;
    //Hall zones
    public HallClass hall;

    // Use this for initialization
    void Awake () {
        agents = new List<GameObject>();
        hofstede = new HofstedeClass();
        cohesion = 0;
        meanSpeed = 1.4f;
        meanSpeedDeviation = (3 - cohesion) / 15;
        hall = new HallClass();
        terrainLimits = new Vector3(GameObject.Find("Terrain").GetComponent<Terrain>().terrainData.size.x, 0, GameObject.Find("Terrain").GetComponent<Terrain>().terrainData.size.z);
    }

    /*void Update(){
        for(int i = 0; i < agents.Count; i++){
            for(int j = 0; j < agents.Count; j++){
                if(i != j){
                    if(Vector3.Distance(agents[i].transform.position, agents[j].transform.position) < personalSpace){
                        float distance = (Vector3.Distance(agents[i].transform.position, agents[j].transform.position))/2;
                        
                    }
                }
            }
        }
    }*/

    //just to update group cell
    public void UpdateCell(float cellRadius) {
        //just to update group cell
        //find all neighbours cells
        int startX = (int)(cell.transform.position.x - (cellRadius * 2f));
        int startZ = (int)(cell.transform.position.z - (cellRadius * 2f));
        int endX = (int)(cell.transform.position.x + (cellRadius * 2f));
        int endZ = (int)(cell.transform.position.z + (cellRadius * 2f));

        //see if it is in some border
        if (cell.transform.position.x == cellRadius)
        {
            startX = (int)cell.transform.position.x;
        }
        if (cell.transform.position.z == cellRadius)
        {
            startZ = (int)cell.transform.position.z;
        }
        if (cell.transform.position.x == terrainLimits.x - cellRadius)
        //if ((int)cell.transform.position.x == 29)
        {
            endX = (int)cell.transform.position.x;
        }
        if (cell.transform.position.z == terrainLimits.z - cellRadius)
        //if ((int)cell.transform.position.z == 29)
        {
            endZ = (int)cell.transform.position.z;
        }

        //distance from agent to cell, to define agent new cell
        float distanceToCell = Vector3.Distance(transform.position, cell.transform.position);
        //Debug.Log(gameObject.name+" -- StartX: "+startX+" -- StartZ: "+startZ+" -- EndX: "+endX+" -- EndZ: "+endZ);
        //iterate to find the cells
        //2 in 2, since the radius of each cell is 1 = diameter 2
        for (float i = startX; i <= endX; i = i + (cellRadius * 2))
        {
            for (float j = startZ; j <= endZ; j = j + (cellRadius * 2))
            {
                float nameX = i - cellRadius;
                float nameZ = j - cellRadius;
                //find the cell
                //GameObject neighbourCell = GameObject.Find("cell" + nameX + "-" + nameZ);
                GameObject neighbourCell = CellController.GetCellByName("Cell" + nameX + "X" + nameZ);

                //if it exists..
                if (neighbourCell)
                {
                    //see distance to this cell
                    //if it is lower, the agent is in another(neighbour) cell
                    float distanceToNeighbourCell = Vector3.Distance(transform.position, neighbourCell.transform.position);
                    if (distanceToNeighbourCell < distanceToCell)
                    {
                        distanceToCell = distanceToNeighbourCell;
                        cell = neighbourCell;
                    }
                }
            }
        }
    }

    //reorder goals/intentions
    public void ReorderGoals()
    {
        for (int i = 0; i < intentions.Count; i++)
        {
            for (int j = i + 1; j < intentions.Count; j++)
            {
                //if j element is bigger, change
                if (intentions[i] < intentions[j])
                {
                    //reorder intentions
                    float temp = intentions[j];
                    intentions[j] = intentions[i];
                    intentions[i] = temp;

                    //reorder desires
                    float tempD = desire[j];
                    desire[j] = desire[i];
                    desire[i] = tempD;

                    //reorder goals
                    GameObject tempG = go[j];
                    go[j] = go[i];
                    go[i] = tempG;
                }
            }
        }
    }

    //transform the cohesion value in a Hall distance value
    //Higher cohesion: until intimate zone
    //Lower cohesion: until personal zone
    public float CohesionToHall(float maxIntimate, float maxPersonal)
    {
        //just for testing all with the same split distance
        //return 3.6f;
        //get the difference between maxPersonal and maxIntimate
        float difference = maxPersonal - maxIntimate;
        //now, divide it by 3 to get the grain variation (since cohesion varies from 0 to 3)
        difference /= 3;

        //return the correspondent Hall value
        //how it works:
        //the maxPersonal value minus cohesion multiplied by the grain difference
        //so, the more cohesion, the less distance between agents
        return (float)(maxPersonal - (cohesion * difference));
        //NEW STUFF: the more cohesion, the more space the group has before split
        //return (float)(maxPersonal - ((3 - cohesion) * difference));
    }

    //getters and setters
    public float GetCohesion()
    {
        return cohesion;
    }
    public void SetCohesion(float value)
    {
        cohesion = value;
    }
    public float GetMeanSpeed()
    {
        return meanSpeed;
    }
    public void SetMeanSpeed(float value)
    {
        meanSpeed = value;
    }
    public float GetMeanSpeedDeviation()
    {
        return meanSpeedDeviation;
    }
    public void SetMeanSpeedDeviation(float value)
    {
        meanSpeedDeviation = value;
    }
}
